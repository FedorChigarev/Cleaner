#!/bin/bash

exec $@
